
import HomePage from "./HomePage";

export default HomePage;
